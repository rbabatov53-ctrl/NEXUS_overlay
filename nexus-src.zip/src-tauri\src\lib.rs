
use serde::Serialize;
use std::{
    io::{BufRead, BufReader},
    path::PathBuf,
    process::{Command, Stdio},
    sync::{Arc, Mutex},
    thread,
    time::Duration,
};
use sysinfo::System;
use tauri::{Manager, State};

#[derive(Serialize, Clone, Default)]
struct GameMetrics {
    fps: Option<u32>,
    frame_time_ms: Option<f64>,
    game_name: Option<String>,
}

#[derive(Serialize)]
struct PcMetrics {
    cpu_usage: f32,
    ram_used_mb: u64,
    ram_total_mb: u64,
    gpu_name: String,
    gpu_usage: Option<u32>,
    gpu_memory_used_mb: Option<u64>,
    gpu_memory_total_mb: Option<u64>,
    gpu_temperature: Option<u32>,
}

#[derive(Serialize, Clone, Default)]
struct NetworkMetrics {
    ping_ms: Option<u32>,
    packet_loss: Option<f64>,
}

struct GameState {
    metrics: Arc<Mutex<GameMetrics>>,
}

struct NetworkState {
    metrics: Arc<Mutex<NetworkMetrics>>,
}

#[tauri::command]
fn get_game_metrics(state: State<'_, GameState>) -> GameMetrics {
    state
        .metrics
        .lock()
        .map(|metrics| metrics.clone())
        .unwrap_or_default()
}

#[tauri::command]
fn get_network_metrics(state: State<'_, NetworkState>) -> NetworkMetrics {
    state
        .metrics
        .lock()
        .map(|metrics| metrics.clone())
        .unwrap_or_default()
}

#[tauri::command]
fn get_pc_metrics() -> PcMetrics {
    let mut system = System::new_all();
    system.refresh_cpu_usage();

    thread::sleep(Duration::from_millis(250));
    system.refresh_cpu_usage();

    let ram_total = system.total_memory() / 1024 / 1024;
    let ram_available = system.available_memory() / 1024 / 1024;

    let output = Command::new("nvidia-smi")
        .args([
            "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
            "--format=csv,noheader,nounits",
        ])
        .output()
        .ok();

    let mut metrics = PcMetrics {
        cpu_usage: system.global_cpu_usage(),
        ram_used_mb: ram_total.saturating_sub(ram_available),
        ram_total_mb: ram_total,
        gpu_name: "NVIDIA GPU".to_string(),
        gpu_usage: None,
        gpu_memory_used_mb: None,
        gpu_memory_total_mb: None,
        gpu_temperature: None,
    };

    if let Some(output) = output.filter(|output| output.status.success()) {
        let line = String::from_utf8_lossy(&output.stdout);
        let parts: Vec<&str> = line.trim().split(',').map(str::trim).collect();

        if parts.len() >= 5 {
            metrics.gpu_name = parts[0].to_string();
            metrics.gpu_usage = parts[1].parse().ok();
            metrics.gpu_memory_used_mb = parts[2].parse().ok();
            metrics.gpu_memory_total_mb = parts[3].parse().ok();
            metrics.gpu_temperature = parts[4].parse().ok();
        }
    }

    metrics
}

fn find_presentmon() -> Option<PathBuf> {
    let filename = "PresentMon-2.6.0-x64.exe";

    if let Ok(exe_path) = std::env::current_exe() {
        if let Some(parent) = exe_path.parent() {
            let candidate = parent.join(filename);
            if candidate.exists() {
                return Some(candidate);
            }
        }
    }

    let candidate = std::env::current_dir()
        .ok()?
        .join("src-tauri")
        .join(filename);

    if candidate.exists() {
        return Some(candidate);
    }

    let candidate = std::env::current_dir().ok()?.join(filename);

    if candidate.exists() {
        return Some(candidate);
    }

    None
}

fn is_game_candidate(application: &str) -> bool {
    let name = application
        .rsplit(['\\', '/'])
        .next()
        .unwrap_or(application)
        .to_ascii_lowercase();

    let ignored = [
        "dwm.exe",
        "explorer.exe",
        "system",
        "idle",
        "registry",
        "searchhost.exe",
        "searchindexer.exe",
        "startmenuexperiencehost.exe",
        "shellexperiencehost.exe",
        "textinputhost.exe",
        "applicationframehost.exe",
        "runtimebroker.exe",
        "taskmgr.exe",
        "conhost.exe",
        "powershell.exe",
        "pwsh.exe",
        "cmd.exe",
        "windowsterminal.exe",
        "nexus-overlay.exe",
        "nexus.exe",
        "incy.exe",
        "obs64.exe",
        "discord.exe",
        "steam.exe",
        "steamwebhelper.exe",
        "epicgameslauncher.exe",
        "epicwebhelper.exe",
        "battle.net.exe",
        "riotclientservices.exe",
        "riotclientux.exe",
        "chrome.exe",
        "msedge.exe",
        "firefox.exe",
        "opera.exe",
        "operagx.exe",
        "brave.exe",
        "spotify.exe",
        "telegram.exe",
        "vlc.exe",
    ];

    if ignored.contains(&name.as_str()) {
        return false;
    }

    let known_games = [
        "cs2.exe",
        "csgo.exe",
        "dota2.exe",
        "valorant-win64-shipping.exe",
        "valorant.exe",
        "r5apex.exe",
        "fortniteclient-win64-shipping.exe",
        "overwatch.exe",
        "overwatch2.exe",
        "minecraft.exe",
        "javaw.exe",
        "java.exe",
        "robloxplayerbeta.exe",
        "gta5.exe",
        "gta5_enhanced.exe",
        "rdr2.exe",
        "eldenring.exe",
        "warface.exe",
        "thedivision2.exe",
        "witcher3.exe",
        "cyberpunk2077.exe",
    ];

    known_games.contains(&name.as_str())
        || name.contains("shipping.exe")
        || name.contains("client-win")
}

fn start_presentmon(metrics: Arc<Mutex<GameMetrics>>, executable: PathBuf) {
    thread::spawn(move || loop {
        let child_result = Command::new(&executable)
            .args([
                "--output_stdout",
                "--v2_metrics",
                "--no_console_stats",
            ])
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn();

        let mut child = match child_result {
            Ok(child) => child,
            Err(error) => {
                eprintln!("Не удалось запустить PresentMon: {error}");
                thread::sleep(Duration::from_secs(3));
                continue;
            }
        };

        if let Some(stdout) = child.stdout.take() {
            let reader = BufReader::new(stdout);

            for line_result in reader.lines() {
                let line = match line_result {
                    Ok(line) => line,
                    Err(error) => {
                        eprintln!("Ошибка чтения PresentMon: {error}");
                        break;
                    }
                };

                let fields: Vec<&str> = line.split(',').collect();

                if fields.len() <= 9
                    || fields[0].eq_ignore_ascii_case("Application")
                {
                    continue;
                }

                let application = fields[0].trim();

                if !is_game_candidate(application) {
                    continue;
                }

                let frame_time = match fields[9].trim().parse::<f64>() {
                    Ok(value) if value.is_finite() && value > 0.0 => value,
                    _ => continue,
                };

                let fps = (1000.0 / frame_time).round() as u32;

                let game_name = application
                    .rsplit(['\\', '/'])
                    .next()
                    .unwrap_or(application)
                    .trim()
                    .to_string();

                if let Ok(mut current) = metrics.lock() {
                    *current = GameMetrics {
                        fps: Some(fps),
                        frame_time_ms: Some(frame_time),
                        game_name: Some(game_name),
                    };
                }
            }
        }

        let _ = child.kill();
        let _ = child.wait();

        if let Ok(mut current) = metrics.lock() {
            *current = GameMetrics::default();
        }

        thread::sleep(Duration::from_secs(2));
    });
}

// Поддерживает ответы ping на английском и русском языках.
// Примеры: time=12ms, time<1ms, время=12мс, время<1мс.
fn parse_ping_ms(output: &str) -> Option<u32> {
    let lower = output.to_lowercase();

    for marker in ["time", "время"] {
        let mut search_from = 0;

        while let Some(relative_index) = lower[search_from..].find(marker) {
            let marker_index = search_from + relative_index;
            let after_marker = marker_index + marker.len();

            let rest = &lower[after_marker..];
            let trimmed = rest.trim_start();

            if let Some(value) = trimmed.strip_prefix('<') {
                let _ = value;
                return Some(1);
            }

            if let Some(value) = trimmed.strip_prefix('=') {
                let value = value.trim_start();

                let digits: String = value
                    .chars()
                    .take_while(|character| character.is_ascii_digit())
                    .collect();

                if let Ok(ms) = digits.parse::<u32>() {
                    return Some(ms);
                }
            }

            search_from = after_marker;

            if search_from >= lower.len() {
                break;
            }
        }
    }

    None
}

fn start_network_monitor(metrics: Arc<Mutex<NetworkMetrics>>) {
    thread::spawn(move || {
        let mut results: Vec<bool> = Vec::with_capacity(20);

        loop {
            // Пробуем основной адрес, а при отсутствии ответа — резервный.
            // Это помогает отличить недоступность одного узла от потери связи.
            let mut successful_ping: Option<u32> = None;

            for address in ["1.1.1.1", "8.8.8.8"] {
                let output = Command::new("ping")
                    .args(["-n", "1", "-w", "1500", address])
                    .output();

                match output {
                    Ok(output) => {
                        let stdout = String::from_utf8_lossy(&output.stdout);
                        let stderr = String::from_utf8_lossy(&output.stderr);
                        let combined = format!("{stdout}\n{stderr}");

                        if let Some(latency) = parse_ping_ms(&combined) {
                            successful_ping = Some(latency);
                            break;
                        }

                        eprintln!(
                            "Ping до {address} не получил распознанного ответа. \
                             Код завершения: {:?}; вывод: {}",
                            output.status.code(),
                            combined.trim()
                        );
                    }
                    Err(error) => {
                        eprintln!("Не удалось запустить ping до {address}: {error}");
                    }
                }
            }

            results.push(successful_ping.is_some());

            if results.len() > 20 {
                results.remove(0);
            }

            let lost = results.iter().filter(|&&success| !success).count();
            let packet_loss = lost as f64 / results.len() as f64 * 100.0;

            if let Ok(mut current) = metrics.lock() {
                current.ping_ms = successful_ping;
                current.packet_loss = Some(packet_loss);
            }

            thread::sleep(Duration::from_secs(1));
        }
    });
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let game_state = GameState {
        metrics: Arc::new(Mutex::new(GameMetrics::default())),
    };

    let game_metrics = Arc::clone(&game_state.metrics);

    let network_state = NetworkState {
        metrics: Arc::new(Mutex::new(NetworkMetrics::default())),
    };

    let network_metrics = Arc::clone(&network_state.metrics);

    tauri::Builder::default()
        .manage(game_state)
        .manage(network_state)
        .setup(move |app| {
            let executable = find_presentmon().or_else(|| {
                app.path()
                    .resource_dir()
                    .ok()
                    .map(|dir| dir.join("PresentMon-2.6.0-x64.exe"))
                    .filter(|path| path.exists())
            });

            if let Some(executable) = executable {
                start_presentmon(game_metrics, executable);
            } else {
                eprintln!("PresentMon-2.6.0-x64.exe не найден");
            }

            start_network_monitor(network_metrics);

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_pc_metrics,
            get_game_metrics,
            get_network_metrics
        ])
        .run(tauri::generate_context!())
        .expect("error while running NEXUS");
}
